/***************************************************************
 * Name:      iocommon.h
 * Purpose:   Implements Basic Cross-platform I/O Functions
 * Author:    Ricardo Garcia (rick.g777 {at} gmail {dot} com)
 * Created:   2008-06-14
 * Copyright: Ricardo Garcia (rick.g777 {at} gmail {dot} com)
 * License:   WxWindows License
 * Comments:  This is a small reimplementation of some
 *            commonly used wxWidgets functions. The functions
 *            were written from scratch based on existing
 *            documentation and web searches, so they need
 *            testing before being released.
 **************************************************************/

#include "iocommon.h"
#include <cstdio>
#include <cstdarg>

std::string ioCommon::GetPathname(std::string fullpath) {
}

std::string ioCommon::GetFilename(std::string fullpath) {
}

bool ioCommon::FileExists(std::string filename) {
   return ioCommon::FileExists(filename.c_str());
}

bool ioCommon::FileExists(const char* filename) {
   FILE * infile;
   bool result = false;
   infile = fopen (filename, "r");
   if (infile != NULL)   {
      result = true;
   }
   fclose(infile);
   return result;
}

const std::string ioCommon::Printf(const char* format, ... ) {
    std::string s;
    va_list arguments;
    unsigned int numchars;
    unsigned long bufsize = 2048;
    {
        char buffer[bufsize]; // We have to set a limit. 2K should be enough for most strings
        numchars = vsnprintf(buffer, bufsize - 1, format, arguments);
        // vsnprintf is a version of sprintf that takes a variable number of arguments. Additionally,
        // it allows you to set a limit on the buffer size used for storing the resulting string.
        // See http://linux.about.com/library/cmd/blcmdl3_vsnprintf.htm

        if(numchars < bufsize - 1) {
            buffer[numchars] = 0;
        } else {
            buffer[bufsize - 1] = 0;
        }
        s = std::string(buffer);
    }
    return s;
}

const std::string ioCommon::PrintfBig(unsigned long bufsize, const char* format, ... ) {
    std::string s;
    va_list arguments;
    unsigned int numchars;
    if(bufsize <= 1) {
        return "";
    } else {
        char buffer[bufsize]; // For big strings
        numchars = vsnprintf(buffer, bufsize - 1, format, arguments);
        if(numchars < bufsize - 1) {
            buffer[numchars] = 0;
        } else {
            buffer[bufsize - 1] = 0;
        }
        s = std::string(buffer);
    }
    return s;
}

TempFile::TempFile(){ }

TempFile::TempFile(const char* filename){ }

TempFile::TempFile(const std::string& filename){ }

bool TempFile::Open(const char* filename){ }

bool TempFile::Open(const std::string& filename){ }

bool TempFile::IsOpened() const{ }

long TempFile::Length() const{ }

long TempFile::Seek(long ofs, ioCommon::SeekType mode){ }

long TempFile::Tell() const{ }

bool TempFile::Write(const void *p, size_t n){ }

bool TempFile::Write(const std::string& str){ }

bool TempFile::Commit(){ }

void TempFile::Discard(){ }

TempFile::~TempFile(){ }

// *** FFile ***

FFile::FFile() : m_file(NULL) {
}

FFile::FFile(const char* filename, const char* mode) {
    m_file = fopen(filename, mode);
}

FFile::~FFile() {
    Close();
}

void FFile::Attach(FILE* fp) {
    m_file = fp;
}

bool FFile::Close() {
    int result = 0;
    if(m_file != NULL) {
        result = fclose(m_file);
        m_file = NULL;
    }
    return (result == 0);
}

void FFile::Detach() {
    m_file = NULL;
}

FILE* FFile::fp() const {
    return m_file;
}

bool FFile::Eof() const {
    if(m_file == NULL)
        return true;
    return feof(m_file);
}

bool FFile::Error() {
    if(m_file == NULL) {
        return false;
    }
    bool result = (ferror(m_file) != 0);
    clearerr(m_file);
    return result;
}

bool FFile::Flush() {
    if(m_file == NULL) {
        return false;
    }
    int result = fflush(m_file);
    return (result == 0);
}

bool FFile::IsOpened() {
    return (m_file != NULL);
}

long FFile::Length() {
    if (m_file == NULL)
        return 0;
    long curlen;
    long oldpos = Tell();
    SeekEnd();
    curlen = Tell();
    Seek(oldpos);
    return curlen;
}

bool FFile::Open(const char* filename, const char* mode) {
    m_file = fopen(filename, mode);
    return IsOpened();
}

bool FFile::Open(const std::string& filename, const char* mode) {
    m_file = fopen(filename.c_str(), mode);
    return IsOpened();
}

size_t FFile::Read(void* buffer, size_t count) {
    if(m_file == NULL) {
        return 0;
    }
    return fread(buffer, 1, count, m_file);
}

bool FFile::ReadAll(std::string* str) {
    if(m_file == NULL) {
        return false;
    }
    long len = Length();
    bool result = false;
    str->clear();
    if(len > 0) {
        char* buffer[len + 1];
        if(Read(buffer, len)) {
            result = true;
        }
        buffer[len] = 0;
        str->append((const char*)buffer);
    }
    return result;
}

bool FFile::Seek(long ofs, ioCommon::SeekType mode) {
    if(m_file == NULL) {
        return false;
    }
    int origin;
    switch(mode) {
        case ioCommon::FromCurrent:
            origin = SEEK_CUR;
        break;
        case ioCommon::FromEnd:
            origin = SEEK_END;
        break;
        case ioCommon::FromStart:
        default:
            origin = SEEK_SET;
    }
    int result = fseek(m_file, ofs, origin);
    return (result == 0);
}

bool FFile::SeekEnd(long ofs)  {
    return Seek(ofs, ioCommon::FromEnd);
}

long FFile::Tell() const {
    if(m_file == NULL)
        return 0;
    return ftell(m_file);
}

size_t FFile::Write(const void* buffer, size_t count) {
    if(m_file == NULL)
        return 0;
    return fwrite(buffer,1,count,m_file);
}

bool FFile::Write(const std::string& s) {
    return Write((const void*)(s.c_str()), s.length());
}
