/***************************************************************
 * Name:      iocommon.h
 * Purpose:   Implements Basic Cross-platform I/O Functions
 * Author:    Ricardo Garcia (rick.g777 {at} gmail {dot} com)
 * Created:   2008-06-14
 * Copyright: Ricardo Garcia (rick.g777 {at} gmail {dot} com)
 * License:   WxWindows License
 * Comments:  This is a small reimplementation of some
 *            commonly used wxWidgets functions. The functions
 *            were written from scratch based on existing
 *            documentation and web searches, so they need
 *            testing before being released.
 **************************************************************/

#include "iocommon.h"
#include <stdio.h>
#include <stdarg.h>

std::string ioCommon::GetPathname(std::string fullpath) {
}

std::string ioCommon::GetFilename(std::string fullpath) {
}

bool ioCommon::FileExists(std::string filename) {
   return ioCommon::FileExists(filename.c_str());
}

bool ioCommon::FileExists(const char* filename) {
   FILE * infile;
   bool result = false;
   infile = fopen (filename, "r");
   if (infile != NULL)   {
      result = true;
   }
   fclose(infile);
   return result;
}

const std::string syString::Format(const char* format, ... ) {
    std::string s;
    va_list arguments;
    unsigned int numchars;
    unsigned long bufsize = 2048;
    {
        char buffer[bufsize]; // We have to set a limit. 2K should be enough for most strings
        numchars = vsnprintf(buffer, bufsize - 1, format, arguments);
        // vsnprintf is a version of sprintf that takes a variable number of arguments. Additionally,
        // it allows you to set a limit on the buffer size used for storing the resulting string.
        // See http://linux.about.com/library/cmd/blcmdl3_vsnprintf.htm

        if(numchars < bufsize - 1) {
            buffer[numchars] = 0;
        } else {
            buffer[bufsize - 1] = 0;
        }
        s = std::string(buffer);
    }
    return s;
}

const std::string syString::FormatBig(unsigned long bufsize, const char* format, ... ) {
    std::string s;
    va_list arguments;
    unsigned int numchars;
    if(bufsize <= 1) {
        return "";
    } else {
        char buffer[bufsize]; // For big strings
        numchars = vsnprintf(buffer, bufsize - 1, format, arguments);
        if(numchars < bufsize - 1) {
            buffer[numchars] = 0;
        } else {
            buffer[bufsize - 1] = 0;
        }
        s = std::string(buffer);
    }
    return s;
}
