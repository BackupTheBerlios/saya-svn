/***************************************************************
 * Name:      iocommon.h
 * Purpose:   Defines Basic Cross-platform I/O Functions
 * Author:    Ricardo Garcia (rick.g777 {at} gmail {dot} com)
 * Created:   2008-06-14
 * Copyright: Ricardo Garcia (rick.g777 {at} gmail {dot} com)
 * License:   WxWindows License
 * Comments:  This is a small reimplementation of some
 *            commonly used wxWidgets functions. The functions
 *            were written from scratch based on existing
 *            documentation and web searches, so they need
 *            testing before being released.
 **************************************************************/

#ifndef iocommon_h
#define iocommon_h

#include <string>
#include <stdio.h>

/** @brief Class for File handling functions
  *
  */
class ioCommon {
    public:
        /** Standard constructor */
        ioCommon() {}

        /** Standard destructor */
        virtual ~ioCommon() {}

        /** @brief Gets the pathname for a filename.
          *
          * @param fullpath The full path to extract the pathname from.
          * @return the pathname of the file.
          */
        static std::string GetPathname(std::string fullpath);

        /** @brief Gets the basename (filename and extension) for a filename.
          *
          * @param fullpath The full path to extract the basename from.
          * @return the name of the file, without path component.
          */
        static std::string GetFilename(std::string fullpath);

        /** @brief Checks for the existance of a file.
          *
          * @param filename the filename to be checked
          * @return true if the file exists; false otherwise.
          */
        static bool FileExists(std::string filename);

        /** @brief Checks for the existance of a file.
          *
          * @param filename the filename to be checked
          * @return true if the file exists; false otherwise.
          */
        static bool FileExists(const char* filename);

};

class BufferedFile {
    public:
        BufferedFile();
        BufferedFile(const char* filename, const char* mode = "r");
        ~BufferedFile();
        void Attach(FILE* fp);
        bool Close();
        void Detach();
        FILE * fp() const;
        bool Eof() const;
        bool Error;
        bool Flush();
        bool IsOpened() const;
        long Length() const;
        bool Open(const char* filename, const char* mode = "r");
        bool Open(const std::string& filename, const char* mode = "r");
        size_t Read(void* buffer, size_t count);
        bool ReadAll(std::string * str);
        bool Seek(long ofs, int mode = 0);
        bool SeekEnd(long ofs = 0);
        long Tell() const;
        size_t Write(const void* buffer, size_t count);
        bool Write(const std::string& s);
    private:
        void* privdata;
        FILE* m_file;
};

class TempFile {
    public:
        TempFile();
        TempFile(const char* filename);
        TempFile(const std::string& filename);
        bool Open(const char* filename);
        bool Open(const std::string& filename);
        bool IsOpened() const;
        long Length() const;
        long Seek(long ofs, int mode = 0);
        long Tell() const;
        bool Write(const void *p, size_t n);
        bool Write(const std::string& str);
        bool Commit();
        void Discard();
        ~TempFile();
    private:
        void* privdata;
};

namespace syString {
    /** Formats a string using sprintf syntax. 2Kbytes max. */
    const std::string Format(const char* format, ... );

    /** Formats a string with maximum length of bufsize - 1, using sprintf syntax. */
    const std::string FormatBig(unsigned long bufsize, const char* format, ... );
};

#endif
